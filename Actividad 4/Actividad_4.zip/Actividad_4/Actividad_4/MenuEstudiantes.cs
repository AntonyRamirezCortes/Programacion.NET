﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_4
{
    public partial class MenuEstudiantes : Form
    {
        public MenuEstudiantes()
        {
            InitializeComponent();
        }

        private void estudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ingreso a menu estudiantes.
            FrmMenu MenuEs = new FrmMenu();
            MenuEs.Show();
            this.Hide();
        }

        private void papeleraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ingreso a papelera.
            FrmPapelera Papelera = new FrmPapelera();
            Papelera.Show();
            this.Hide();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //inigreso a informacion.
            Informacion informacion = new Informacion();
            informacion.Show();
            this.Hide();
        }

        private void MenuEstudiantes_Load(object sender, EventArgs e)
        {

        }
    }
}
