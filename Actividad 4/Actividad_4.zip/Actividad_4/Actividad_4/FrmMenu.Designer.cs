﻿namespace Actividad_4
{
    partial class FrmMenu
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txtcorreo = new System.Windows.Forms.TextBox();
            this.txtn1 = new System.Windows.Forms.TextBox();
            this.txtn3 = new System.Windows.Forms.TextBox();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.txtn4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Menuicons = new System.Windows.Forms.ToolStrip();
            this.tsbabrirarchivo = new System.Windows.Forms.ToolStripButton();
            this.tsbagregarusuario = new System.Windows.Forms.ToolStripButton();
            this.tsrbuscarusuario = new System.Windows.Forms.ToolStripButton();
            this.tsbeditarusuario = new System.Windows.Forms.ToolStripButton();
            this.tsbeliminarusuario = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.tsbguardararchivo = new System.Windows.Forms.ToolStripButton();
            this.tsbExit = new System.Windows.Forms.ToolStripButton();
            this.dgvdatos = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.errordatos = new System.Windows.Forms.ErrorProvider(this.components);
            this.dgborrados1 = new System.Windows.Forms.DataGridView();
            this.Menuicons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errordatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgborrados1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 146);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codigo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 192);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 235);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo";
            // 
            // txtcodigo
            // 
            this.txtcodigo.Location = new System.Drawing.Point(86, 143);
            this.txtcodigo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.Size = new System.Drawing.Size(148, 26);
            this.txtcodigo.TabIndex = 3;
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(86, 189);
            this.txtnombre.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(648, 26);
            this.txtnombre.TabIndex = 4;
            // 
            // txtcorreo
            // 
            this.txtcorreo.Location = new System.Drawing.Point(86, 232);
            this.txtcorreo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcorreo.Name = "txtcorreo";
            this.txtcorreo.Size = new System.Drawing.Size(648, 26);
            this.txtcorreo.TabIndex = 5;
            // 
            // txtn1
            // 
            this.txtn1.Location = new System.Drawing.Point(86, 268);
            this.txtn1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtn1.Name = "txtn1";
            this.txtn1.Size = new System.Drawing.Size(60, 26);
            this.txtn1.TabIndex = 6;
            // 
            // txtn3
            // 
            this.txtn3.Location = new System.Drawing.Point(407, 268);
            this.txtn3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtn3.Name = "txtn3";
            this.txtn3.Size = new System.Drawing.Size(60, 26);
            this.txtn3.TabIndex = 7;
            // 
            // txtn2
            // 
            this.txtn2.Location = new System.Drawing.Point(240, 268);
            this.txtn2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(60, 26);
            this.txtn2.TabIndex = 8;
            // 
            // txtn4
            // 
            this.txtn4.Location = new System.Drawing.Point(574, 268);
            this.txtn4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtn4.Name = "txtn4";
            this.txtn4.Size = new System.Drawing.Size(60, 26);
            this.txtn4.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 271);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nota-1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(500, 271);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Nota-4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(337, 271);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "nota-3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(164, 271);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Nota-2";
            // 
            // Menuicons
            // 
            this.Menuicons.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Menuicons.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbabrirarchivo,
            this.tsbagregarusuario,
            this.tsrbuscarusuario,
            this.tsbeditarusuario,
            this.tsbeliminarusuario,
            this.toolStripButton1,
            this.tsbguardararchivo,
            this.tsbExit});
            this.Menuicons.Location = new System.Drawing.Point(0, 0);
            this.Menuicons.Name = "Menuicons";
            this.Menuicons.Padding = new System.Windows.Forms.Padding(0);
            this.Menuicons.Size = new System.Drawing.Size(746, 97);
            this.Menuicons.TabIndex = 14;
            this.Menuicons.Text = "toolStrip1";
            // 
            // tsbabrirarchivo
            // 
            this.tsbabrirarchivo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbabrirarchivo.Image = ((System.Drawing.Image)(resources.GetObject("tsbabrirarchivo.Image")));
            this.tsbabrirarchivo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbabrirarchivo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbabrirarchivo.Margin = new System.Windows.Forms.Padding(1);
            this.tsbabrirarchivo.Name = "tsbabrirarchivo";
            this.tsbabrirarchivo.Padding = new System.Windows.Forms.Padding(1);
            this.tsbabrirarchivo.Size = new System.Drawing.Size(86, 95);
            this.tsbabrirarchivo.Text = "toolStripButton1";
            this.tsbabrirarchivo.ToolTipText = "Abrir Archivo XML";
            this.tsbabrirarchivo.Click += new System.EventHandler(this.tsbabrirarchivo_Click);
            // 
            // tsbagregarusuario
            // 
            this.tsbagregarusuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbagregarusuario.Image = ((System.Drawing.Image)(resources.GetObject("tsbagregarusuario.Image")));
            this.tsbagregarusuario.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbagregarusuario.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbagregarusuario.Margin = new System.Windows.Forms.Padding(1);
            this.tsbagregarusuario.Name = "tsbagregarusuario";
            this.tsbagregarusuario.Padding = new System.Windows.Forms.Padding(1);
            this.tsbagregarusuario.Size = new System.Drawing.Size(86, 95);
            this.tsbagregarusuario.Text = "toolStripButton2";
            this.tsbagregarusuario.ToolTipText = "Nuevo Estudiante";
            this.tsbagregarusuario.Click += new System.EventHandler(this.tsbagregarusuario_Click);
            // 
            // tsrbuscarusuario
            // 
            this.tsrbuscarusuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsrbuscarusuario.Image = ((System.Drawing.Image)(resources.GetObject("tsrbuscarusuario.Image")));
            this.tsrbuscarusuario.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsrbuscarusuario.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbuscarusuario.Margin = new System.Windows.Forms.Padding(1);
            this.tsrbuscarusuario.Name = "tsrbuscarusuario";
            this.tsrbuscarusuario.Padding = new System.Windows.Forms.Padding(1);
            this.tsrbuscarusuario.Size = new System.Drawing.Size(86, 95);
            this.tsrbuscarusuario.Text = "toolStripButton3";
            this.tsrbuscarusuario.ToolTipText = "Buscar Estudiante";
            this.tsrbuscarusuario.Click += new System.EventHandler(this.tsrbuscarusuario_Click);
            // 
            // tsbeditarusuario
            // 
            this.tsbeditarusuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbeditarusuario.Enabled = false;
            this.tsbeditarusuario.Image = ((System.Drawing.Image)(resources.GetObject("tsbeditarusuario.Image")));
            this.tsbeditarusuario.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbeditarusuario.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbeditarusuario.Margin = new System.Windows.Forms.Padding(1);
            this.tsbeditarusuario.Name = "tsbeditarusuario";
            this.tsbeditarusuario.Padding = new System.Windows.Forms.Padding(1);
            this.tsbeditarusuario.Size = new System.Drawing.Size(86, 95);
            this.tsbeditarusuario.Text = "toolStripButton4";
            this.tsbeditarusuario.ToolTipText = "Editar Estudiante";
            this.tsbeditarusuario.Click += new System.EventHandler(this.tsbeditarusuario_Click);
            // 
            // tsbeliminarusuario
            // 
            this.tsbeliminarusuario.AutoSize = false;
            this.tsbeliminarusuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbeliminarusuario.Enabled = false;
            this.tsbeliminarusuario.Image = ((System.Drawing.Image)(resources.GetObject("tsbeliminarusuario.Image")));
            this.tsbeliminarusuario.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbeliminarusuario.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbeliminarusuario.Margin = new System.Windows.Forms.Padding(1);
            this.tsbeliminarusuario.Name = "tsbeliminarusuario";
            this.tsbeliminarusuario.Padding = new System.Windows.Forms.Padding(1);
            this.tsbeliminarusuario.Size = new System.Drawing.Size(86, 86);
            this.tsbeliminarusuario.Text = "toolStripButton5";
            this.tsbeliminarusuario.ToolTipText = "Eliminar Estudiante";
            this.tsbeliminarusuario.Click += new System.EventHandler(this.tsbeliminarusuario_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Padding = new System.Windows.Forms.Padding(5);
            this.toolStripButton1.Size = new System.Drawing.Size(94, 94);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // tsbguardararchivo
            // 
            this.tsbguardararchivo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbguardararchivo.Image = ((System.Drawing.Image)(resources.GetObject("tsbguardararchivo.Image")));
            this.tsbguardararchivo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbguardararchivo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbguardararchivo.Margin = new System.Windows.Forms.Padding(1);
            this.tsbguardararchivo.Name = "tsbguardararchivo";
            this.tsbguardararchivo.Padding = new System.Windows.Forms.Padding(1);
            this.tsbguardararchivo.Size = new System.Drawing.Size(86, 95);
            this.tsbguardararchivo.Text = "toolStripButton6";
            this.tsbguardararchivo.ToolTipText = "Guardar Archivo XML";
            this.tsbguardararchivo.Click += new System.EventHandler(this.tsbguardararchivo_Click);
            // 
            // tsbExit
            // 
            this.tsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExit.Image = ((System.Drawing.Image)(resources.GetObject("tsbExit.Image")));
            this.tsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExit.Margin = new System.Windows.Forms.Padding(1);
            this.tsbExit.Name = "tsbExit";
            this.tsbExit.Padding = new System.Windows.Forms.Padding(1);
            this.tsbExit.Size = new System.Drawing.Size(86, 95);
            this.tsbExit.Text = "toolStripButton7";
            this.tsbExit.ToolTipText = "Salir";
            this.tsbExit.Click += new System.EventHandler(this.tsbExit_Click);
            // 
            // dgvdatos
            // 
            this.dgvdatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdatos.Location = new System.Drawing.Point(12, 311);
            this.dgvdatos.Name = "dgvdatos";
            this.dgvdatos.Size = new System.Drawing.Size(722, 182);
            this.dgvdatos.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Wide Latin", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(165, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(299, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "DATOS DEL ESTUDIANTE";
            // 
            // errordatos
            // 
            this.errordatos.ContainerControl = this;
            // 
            // dgborrados1
            // 
            this.dgborrados1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgborrados1.Location = new System.Drawing.Point(12, 502);
            this.dgborrados1.Name = "dgborrados1";
            this.dgborrados1.Size = new System.Drawing.Size(722, 156);
            this.dgborrados1.TabIndex = 17;
            this.dgborrados1.Visible = false;
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 670);
            this.Controls.Add(this.dgborrados1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgvdatos);
            this.Controls.Add(this.Menuicons);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtn4);
            this.Controls.Add(this.txtn2);
            this.Controls.Add(this.txtn3);
            this.Controls.Add(this.txtn1);
            this.Controls.Add(this.txtcorreo);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.txtcodigo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmcalculoNotas";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Menuicons.ResumeLayout(false);
            this.Menuicons.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errordatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgborrados1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcodigo;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.TextBox txtcorreo;
        private System.Windows.Forms.TextBox txtn1;
        private System.Windows.Forms.TextBox txtn3;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.TextBox txtn4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ToolStrip Menuicons;
        private System.Windows.Forms.ToolStripButton tsbabrirarchivo;
        private System.Windows.Forms.ToolStripButton tsbagregarusuario;
        private System.Windows.Forms.ToolStripButton tsrbuscarusuario;
        private System.Windows.Forms.ToolStripButton tsbeditarusuario;
        private System.Windows.Forms.ToolStripButton tsbeliminarusuario;
        private System.Windows.Forms.ToolStripButton tsbguardararchivo;
        private System.Windows.Forms.ToolStripButton tsbExit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ErrorProvider errordatos;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        public System.Windows.Forms.DataGridView dgborrados1;
        public System.Windows.Forms.DataGridView dgvdatos;
    }
}

