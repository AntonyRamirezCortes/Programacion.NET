﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Actividad_4
{
    class clsverificaciondatos
    {

        public Boolean Vacio(/*Dato que se esta analizando*/TextBox Datos, /*Respuesta de la validacion*/ErrorProvider Mensaje, string MensajeError)
        {
            //------------------validar vacio
            if (Datos.Text == "")
            {
                Mensaje.SetError(Datos, MensajeError);
                Datos.Focus();
                return true;
            }
            else
            {
                Mensaje.Clear();
                return false;
            }
        }

        public Boolean TipoNumero(TextBox caja, ErrorProvider error, string MensajeError)
        {

            Regex formatotexto = new Regex("[0-9]{1,9}(\\.[0-9]{0,2})?$");
            {

                if (!formatotexto.IsMatch(caja.Text))
                {
                    error.SetError(caja, MensajeError);
                    caja.Focus();
                    return false;
                }
                else
                {
                    error.Clear();
                    return true;
                }
               
            } 

        }

        public Boolean TipoTexto(TextBox caja, ErrorProvider Error, string MensajeError)
        {
            Regex Formato = new Regex("[a-zA-ZñÑ\\s]{2,50}");
            if (!Formato.IsMatch(caja.Text))
            {
                Error.SetError(caja, MensajeError);
                caja.Focus();
                return false;
            }
            else
            {
                Error.Clear();
                return true;
            }
        }

        public Boolean TipoCorreo(TextBox caja, ErrorProvider Error, string MensajeError)
        {
            Regex FormatoCorreo = new Regex("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");

            if (!FormatoCorreo.IsMatch(caja.Text))
            {
                Error.SetError(caja, MensajeError);
                caja.Focus();
                return false;
            }
            else
            {
                Error.Clear();
                return true;
            }
        }


    }
}
