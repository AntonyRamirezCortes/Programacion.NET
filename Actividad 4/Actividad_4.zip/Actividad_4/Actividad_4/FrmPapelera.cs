﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Xml.Serialization;
using System.IO;
using System.Threading;

namespace Actividad_4
{
    public partial class FrmPapelera : Form
    {
        List<clsestudiante> ListaAlumnosR = new List<clsestudiante>();
        clsverificaciondatos validacion = new clsverificaciondatos();
        List<clsestudiante> AlumnosBorrados = new List<clsestudiante>();
        List<clsestudiante> ListaAlumnos = new List<clsestudiante>();


        public FrmPapelera()
        {
            InitializeComponent();
        }

        private void FrmPapelera_Load(object sender, EventArgs e)
        {
            FrmMenu Alumnos = new FrmMenu();
            //cuando se abra lea el archivo y lo muestre.
            //cargar los datos del xml.
            //generar una lista con esos datos.
            //mostrar esa lista en el DG.
            AlumnosBorrados.Clear();

            if (File.Exists("C:/NET/AlumnosBorrados.xml"))
            {
                XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
                FileStream LeerXml = File.OpenRead("C:/NET/AlumnosBorrados.xml");
                AlumnosBorrados = (List<clsestudiante>)Codificador.Deserialize(LeerXml);
                LeerXml.Close();

                XmlSerializer Codificador1 = new XmlSerializer(typeof(List<clsestudiante>));
                FileStream LeerXml1 = File.OpenRead("C:/NET/ListaAlumno.xml");
                ListaAlumnos = (List<clsestudiante>)Codificador1.Deserialize(LeerXml1);
                LeerXml.Close();             
            }
            dgrecuperados.DataSource = ListaAlumnos;
            dgborrados.DataSource = null;
            dgborrados.DataSource = AlumnosBorrados;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            FrmMenu Menu = new FrmMenu();
            Menu.Show();
            this.Close();

            //cuando se pase de un formulario a otro se cree un archivo xml.            
            XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml = new StreamWriter("C:/NET/ListaAlumno.xml");//Debug si no le pongo rut
            Codificador.Serialize(EscribirXml, ListaAlumnos);
            EscribirXml.Close();

            XmlSerializer Codificador1 = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml1 = new StreamWriter("C:/NET/AlumnosBorrados.xml");//Debug si no le pongo ruta
            Codificador1.Serialize(EscribirXml1, AlumnosBorrados);
            EscribirXml.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //Vamos a buscar a un estudiante por el codigo.
            //Valido que no este vacia la caja y que sean valores numericos.

            if (!validacion.Vacio(txtcodigoB, errordatos, "Para buscar debe haber un codigo"))
            {
                if (validacion.TipoNumero(txtcodigoB, errordatos, "El codigo debe ser numerico"))
                {
                    //Validar que exista
                    if (ExisteCod(Convert.ToInt32(txtcodigoB.Text)))
                    {
                        clsestudiante MyAlumno = ObtenerDatos(Convert.ToInt32(txtcodigoB.Text));
                        txtnombreB.Text = MyAlumno.Nombre;
                        txtcorreoB.Text = MyAlumno.Correo;
                        txtn1B.Text = MyAlumno.Nota1.ToString();
                        txtn2B.Text = MyAlumno.Nota2.ToString();
                        txtn3B.Text = MyAlumno.Nota3.ToString();
                        txtn4B.Text = MyAlumno.Nota4.ToString();                        
                    }
                    else
                    {
                        errordatos.SetError(txtcodigoB, "Codigo no exste");
                        txtcodigoB.Focus();
                        LimpiarCajas2();
                        return;
                    }
                }
            }
        }

        private Boolean ExisteCod(int codigo)
        {
            foreach (clsestudiante Myestudiante in AlumnosBorrados)
            {
                if (Myestudiante.Codigo == codigo)
                {
                    return true;
                }
            }
            return false;
        }

        private clsestudiante ObtenerDatos(int codigo)
        {
            foreach (clsestudiante MyAlumno in AlumnosBorrados)
            {
                if (MyAlumno.Codigo == codigo)
                {
                    return MyAlumno;
                }
            }
            return null;
        }

        private void LimpiarCajas2()
        {
            txtnombreB.Clear();
            txtcorreoB.Clear();
            txtn1B.Clear();
            txtn2B.Clear();
            txtn3B.Clear();
            txtn4B.Clear();
            txtcodigoB.Focus();
        }

        private void LimpiarCajas()
        {
            txtcodigoB.Clear();
            txtnombreB.Clear();
            txtcorreoB.Clear();
            txtn1B.Clear();
            txtn2B.Clear();
            txtn3B.Clear();
            txtn4B.Clear();
            txtcodigoB.Focus();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

            FrmMenu recuperados = new FrmMenu();
            
            //Recuperar estudiante
            /*al recuperar estudiante nos remueve el estudiante seleccionado de el
             * dg y crea nuestro xml para actualizar los alu,nos borrados.
             y no lo envia a datos recuperados para devolverlo a listaAlumnos.*/
            DialogResult ConfirmarBorrar = MessageBox.Show("Desea Recuperar El Alumno", "Confirmar Borrada", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (ConfirmarBorrar == DialogResult.OK)
            {
                clsestudiante MyAlumno = ObtenerDatos(Convert.ToInt32(txtcodigoB.Text));
                AlumnosBorrados.Remove(MyAlumno);
                dgborrados.DataSource = null;
                dgborrados.DataSource = AlumnosBorrados;
                InsertarDatosRecuperados();
                FrmPapelera borrados = new FrmPapelera();

                //crear nuestro archivo xml de los alumnos Borrados
                XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
                TextWriter EscribirXml = new StreamWriter("C:/NET/AlumnosBorrados.xml");//Debug si no le pongo rut
                Codificador.Serialize(EscribirXml, ListaAlumnosR);
                EscribirXml.Close();
                LimpiarCajas();
            }

        }

        private void InsertarDatosRecuperados()
        {            
            //--------------------------------AGREGAR ALUMNO

            clsestudiante objAlumno = new clsestudiante(); //Instancio la clase alumno y creo el objeto objAlumno // crea objeto objAlumno            
            //--------------------------------VALIDAR CAMPOS VACIOS

            //Desde los elementos del formulario creo el alumno nuevo
            objAlumno.Codigo = Convert.ToInt32(txtcodigoB.Text);
            objAlumno.Nombre = txtnombreB.Text;
            objAlumno.Correo = txtcorreoB.Text;
            objAlumno.Nota1 = Convert.ToDouble(txtn1B.Text);
            objAlumno.Nota2 = Convert.ToDouble(txtn2B.Text);
            objAlumno.Nota3 = Convert.ToDouble(txtn3B.Text);
            objAlumno.Nota4 = Convert.ToDouble(txtn4B.Text);
            //------------------------------------calculamos los demas valores
            objAlumno.NotaFinal = (objAlumno.Nota1 + objAlumno.Nota2 + objAlumno.Nota3 + objAlumno.Nota4) / 4;
            if (objAlumno.NotaFinal >= 3.5)
            {
                objAlumno.NotaConcepto = "Aprobado";
            }
            else
            {
                objAlumno.NotaConcepto = "Reprobado";
            }            
            //agrego el objeto alumno al arreglo

            ListaAlumnos.Add(objAlumno);

            //alimento el datagrid o visualizo en el dg el arreglo
            FrmMenu Recuperar = new FrmMenu();
            dgrecuperados.DataSource = null;
            dgrecuperados.DataSource = ListaAlumnos;            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            //Cerrar la aplicacion
            //Cuando se cierra se guarde la informacion
            //crear nuestro archivo xml...........
            XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml = new StreamWriter("C:/NET/ListaAlumno.xml");//Debug si no le pongo rut
            Codificador.Serialize(EscribirXml, ListaAlumnos);
            EscribirXml.Close();

            XmlSerializer Codificador1 = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml1 = new StreamWriter("C:/NET/AlumnosBorrados.xml");//Debug si no le pongo ruta
            Codificador1.Serialize(EscribirXml1, AlumnosBorrados);
            EscribirXml.Close();
        }
    }
}

   

