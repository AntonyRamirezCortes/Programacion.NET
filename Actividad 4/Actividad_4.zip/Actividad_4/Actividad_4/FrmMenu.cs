﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;//manejo de archivos xml

namespace Actividad_4
{
    public partial class FrmMenu : Form
    {

        //-----------------instanciar la clase---------------------
        clsverificaciondatos validacion = new clsverificaciondatos();        

        List<clsestudiante> AlumnosBorrados = new List<clsestudiante>();

       //------------------Creamos objetos lista alumno-------------
        List<clsestudiante> ListaAlumnos = new List<clsestudiante>(); 

        public FrmMenu()
        {
            InitializeComponent();
        }                      
        private void tsbagregarusuario_Click(object sender, EventArgs e)
        {
            
            //Realizamos validaciones de campos vacios y textos validos.
            if (!validacion.Vacio(txtcodigo, errordatos, "Campo obligatorio"))
            {
                if (validacion.TipoNumero(txtcodigo, errordatos, "Codigo invalido"))
                {
                    if (!validacion.Vacio(txtnombre, errordatos, "Campo obligatorio"))
                    {
                        if (validacion.TipoTexto(txtnombre, errordatos, "Nombre invalido"))
                        {
                            if (!validacion.Vacio(txtcorreo, errordatos, "Campo obligatorio"))
                            {
                                if (validacion.TipoCorreo(txtcorreo, errordatos, "Correo invalido"))
                                {
                                    if (!validacion.Vacio(txtn1, errordatos, "Campo obligatorio"))
                                    {
                                        if (validacion.TipoNumero(txtn1, errordatos, "Nota invalida"))
                                        {
                                            if (!validacion.Vacio(txtn2, errordatos, "Campo obligatorio"))
                                            {
                                                if (validacion.TipoNumero(txtn2, errordatos, "nota invalida"))
                                                {
                                                    if (!validacion.Vacio(txtn3, errordatos, "Campo obligatorio"))
                                                    {
                                                        if (validacion.TipoNumero(txtn3, errordatos, "Nota invalida"))
                                                        {
                                                            if (!validacion.Vacio(txtn4, errordatos, "Campo obligatorio"))
                                                            {
                                                                if (validacion.TipoNumero(txtn4, errordatos, "Nota invalida"))
                                                                {

                                                                    if (!ExisteCod(Convert.ToInt32(txtcodigo.Text)))
                                                                    {
                                                                        //llamo insertar datos
                                                                        InsertarDatos();
                                                                        //Limpiar cajas
                                                                        LimpiarCajas();
                                                                        errordatos.Clear();
                                                                    }
                                                                    else
                                                                    {
                                                                        errordatos.SetError(txtcodigo, "El codigo ya existe");
                                                                        txtcodigo.Focus();
                                                                        return;
                                                                    }
                                                                }
                                                            }
                                                        }                                                       
                                                    }
                                                }                                               
                                            }
                                        }                                        
                                    }
                                }                               
                            }
                        }                        
                    }
                }                         
            }            
        }               
        private void tsbguardararchivo_Click(object sender, EventArgs e)//Boton guardar xml en el menu
        {            
            //crear nuestro archivo xml...........
            XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml = new StreamWriter("C:/NET/ListaAlumno.xml");//Debug si no le pongo rut
            Codificador.Serialize(EscribirXml, ListaAlumnos);
            EscribirXml.Close();

            XmlSerializer Codificador1 = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml1 = new StreamWriter("C:/NET/AlumnosBorrados.xml");//Debug si no le pongo ruta
            Codificador1.Serialize(EscribirXml1, AlumnosBorrados);
            EscribirXml.Close();            
        }

        private void tsbabrirarchivo_Click(object sender, EventArgs e)//Abrir archivo xml
        {
            //cargar los datos del los archivos xml y generar una lista con esos datos para hacelos visibles en los dg.                  
            FrmMenu Menu = new FrmMenu();
            FrmPapelera borrados = new FrmPapelera();
            XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
            FileStream LeerXml = File.OpenRead("C:/NET/AlumnosBorrados.xml");
            AlumnosBorrados = (List<clsestudiante>)Codificador.Deserialize(LeerXml);
            LeerXml.Close();

            dgborrados1.DataSource = null;
            dgborrados1.DataSource = AlumnosBorrados;
        }

        
       
        private void Form1_Load(object sender, EventArgs e) //Evento de cargar el formulario
        {
            //cuando se abra lea el archivo y lo muestre
            //cargar los datos del xml
            //generar una lista con esos datos
            //mostrar esa lista en el DG
            ListaAlumnos.Clear();

            if (File.Exists("C:/NET/ListaAlumno.xml")) 
            {
                XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
                FileStream LeerXml = File.OpenRead("C:/NET/ListaAlumno.xml");
                ListaAlumnos = (List<clsestudiante>)Codificador.Deserialize(LeerXml);
                LeerXml.Close();

                dgvdatos.DataSource = null;
                dgvdatos.DataSource = ListaAlumnos;

                XmlSerializer Codificador1 = new XmlSerializer(typeof(List<clsestudiante>));
                FileStream LeerXml1 = File.OpenRead("C:/NET/AlumnosBorrados.xml");
                AlumnosBorrados = (List<clsestudiante>)Codificador1.Deserialize(LeerXml1);
                LeerXml1.Close();

                dgborrados1.DataSource = null;
                dgborrados1.DataSource = AlumnosBorrados;

            }                                
            
           
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)//Evento de cerrar el formulario
        {
            //Cuando se cierra se guarde la informacion
            //crear nuestros archivo xml...........
            XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml = new StreamWriter("C:/NET/ListaAlumno.xml");//Debug si no le pongo rut
            /*TextWriter EscribirXmlB = new StreamWriter("C:/NET/AlumnosBorrados.xml");*/
            Codificador.Serialize(EscribirXml, ListaAlumnos);            
            EscribirXml.Close();            
        }

        private void tsbExit_Click(object sender, EventArgs e)//Boton salir
        {
            //Cerrar la aplicacion
            //Cuando se cierra se guarde la informacion
            //crear nuestros archivo xml...........
            XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml = new StreamWriter("C:/NET/ListaAlumno.xml");//Debug si no le pongo rut
            Codificador.Serialize(EscribirXml, ListaAlumnos);
            EscribirXml.Close();

            XmlSerializer Codificador1 = new XmlSerializer(typeof(List<clsestudiante>));
            TextWriter EscribirXml1 = new StreamWriter("C:/NET/AlumnosBorrados.xml");//Debug si no le pongo ruta
            Codificador1.Serialize(EscribirXml1, AlumnosBorrados);
            EscribirXml.Close();
            Application.Exit();
        }
       

        private void tsrbuscarusuario_Click(object sender, EventArgs e)//Boton buscar
        {
            //Vamos a buscar a un estudiante por el codigo
            //Valido que no este vacia la caja y que el valor sea numerico

            if (!validacion.Vacio(txtcodigo, errordatos, "Para buscar debe haber un codigo"))
            {
                if (validacion.TipoNumero(txtcodigo, errordatos, "El codigo debe ser numerico"))
                {
                    //Validar que exista
                    if (ExisteCod(Convert.ToInt32(txtcodigo.Text)))
                    {
                        clsestudiante MyAlumno = ObtenerDatos(Convert.ToInt32(txtcodigo.Text));
                        txtnombre.Text = MyAlumno.Nombre;
                        txtcorreo.Text = MyAlumno.Correo;
                        txtn1.Text = MyAlumno.Nota1.ToString();
                        txtn2.Text = MyAlumno.Nota2.ToString();
                        txtn3.Text = MyAlumno.Nota3.ToString();
                        txtn4.Text = MyAlumno.Nota4.ToString();

                        //avtivar los botones
                        tsbeditarusuario.Enabled = true;
                        tsbeliminarusuario.Enabled = true;
                        txtcodigo.Enabled = false;

                    }
                    else
                    {
                        errordatos.SetError(txtcodigo, "Codigo no exste");
                        txtcodigo.Focus();
                        LimpiarCajas2();
                        return;
                    }
                }
                
            }
        }      
        //Traemos el objeto de un alumno
        private clsestudiante ObtenerDatos (int codigo)
        {
            foreach (clsestudiante MyAlumno in ListaAlumnos)
            {
                if (MyAlumno.Codigo == codigo)
                {
                    return MyAlumno;
                }              
            }
            return null;
        }
        private void tsbeditarusuario_Click(object sender, EventArgs e)//Boton Editar
        {
            //Editar Datos
            if (!validacion.Vacio(txtnombre, errordatos, "Campo obligatorio"))
            {
                if (validacion.TipoTexto(txtnombre, errordatos, "Nombre invalido"))
                {
                    if (!validacion.Vacio(txtcorreo, errordatos, "Campo obligatorio"))
                    {
                        if (validacion.TipoCorreo(txtcorreo, errordatos, "Correo invalido"))
                        {
                            if (!validacion.Vacio(txtn1, errordatos, "Campo obligatorio"))
                            {
                                if (validacion.TipoNumero(txtn1, errordatos, "Nota invalida"))
                                {
                                    if (!validacion.Vacio(txtn2, errordatos, "Campo obligatorio"))
                                    {
                                        if (validacion.TipoNumero(txtn2, errordatos, "nota invalida"))
                                        {
                                            if (!validacion.Vacio(txtn3, errordatos, "Campo obligatorio"))
                                            {
                                                if (validacion.TipoNumero(txtn3, errordatos, "Nota invalida"))
                                                {
                                                    if (!validacion.Vacio(txtn4, errordatos, "Campo obligatorio"))
                                                    {
                                                        if (validacion.TipoNumero(txtn4, errordatos, "Nota invalida"))
                                                        {
                                                            //cuando editar cambios pase todas las validaciones guarda los cambios realizados.
                                                            GuardarCambios();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //-------------------------mis metodos-------------------------------        
        //Aca vamos a usar metodos para la validacion y manipulacion de datos.

        //Vaildar que el nuevo codigo no exista en la lista

        private Boolean ExisteCod(int codigo)
        {
            foreach (clsestudiante Myestudiante in ListaAlumnos)
            {
                if (Myestudiante.Codigo == codigo)
                {
                    return true;
                }
            }
            return false;
        }

        private void LimpiarCajas()
        {
            txtcodigo.Clear();
            txtnombre.Clear();
            txtcorreo.Clear();
            txtn1.Clear();
            txtn2.Clear();
            txtn3.Clear();
            txtn4.Clear();
            txtcodigo.Focus();
        }
        private void LimpiarCajas2()
        {
            txtnombre.Clear();
            txtcorreo.Clear();
            txtn1.Clear();
            txtn2.Clear();
            txtn3.Clear();
            txtn4.Clear();
            txtcodigo.Focus();
        }

         private void verArreglo()//Metodo para ver el arreglo
        {
            foreach (clsestudiante itemAlumno in ListaAlumnos)
            {
                Console.WriteLine("------------------------");
                Console.WriteLine(itemAlumno.Codigo);
                Console.WriteLine(itemAlumno.Nombre);
                Console.WriteLine(itemAlumno.Correo);
                Console.WriteLine(itemAlumno.Nota1);
                Console.WriteLine(itemAlumno.Nota2);
                Console.WriteLine(itemAlumno.Nota3);
                Console.WriteLine(itemAlumno.Nota4);
                Console.WriteLine(itemAlumno.NotaFinal);
                Console.WriteLine(itemAlumno.NotaConcepto);
                Console.WriteLine("------------------------");
            }
        }     

        private void GuardarCambios()
        {
            //Metodo Crea un objeto Alumno "con el codigo que esta en la caja de texto correspondiente"
            //como el objeto es de la lista actualiza los valores
            clsestudiante MyAlumno = ObtenerDatos(Convert.ToInt32(txtcodigo.Text));
            MyAlumno.Nombre = txtnombre.Text;
            MyAlumno.Correo = txtcorreo.Text;
            MyAlumno.Nota1 = Convert.ToDouble(txtn1.Text);
            MyAlumno.Nota2 = Convert.ToDouble(txtn2.Text);
            MyAlumno.Nota3 = Convert.ToDouble(txtn3.Text);
            MyAlumno.Nota4 = Convert.ToDouble(txtn4.Text);
            //------------------------------------calculamos los demas valores
            MyAlumno.NotaFinal = (MyAlumno.Nota1 + MyAlumno.Nota2 + MyAlumno.Nota3 + MyAlumno.Nota4) / 4;
            if (MyAlumno.NotaFinal >= 3.5)
            {
                MyAlumno.NotaConcepto = "Aprobado";
            }
            else
            {
                MyAlumno.NotaConcepto = "Reprobado";
            }

            dgvdatos.DataSource = null;
            dgvdatos.DataSource = ListaAlumnos;


            //Activar Botones

            tsbeditarusuario.Enabled = false;
            tsbeliminarusuario.Enabled = false;
            txtcodigo.Enabled = true;
            LimpiarCajas();
        }

        private void InsertarDatos()
        {
            //--------------------------------AGREGAR ALUMNO

            //Instancio la clase alumno y creo el objeto objAlumno.
            clsestudiante objAlumno = new clsestudiante(); 

            //--------------------------------VALIDAR CAMPOS VACIOS

            //Desde los elementos del formulario creo el alumno nuevo
            objAlumno.Codigo = Convert.ToInt32(txtcodigo.Text);
            objAlumno.Nombre = txtnombre.Text;
            objAlumno.Correo = txtcorreo.Text;
            objAlumno.Nota1 = Convert.ToDouble(txtn1.Text);
            objAlumno.Nota2 = Convert.ToDouble(txtn2.Text);
            objAlumno.Nota3 = Convert.ToDouble(txtn3.Text);
            objAlumno.Nota4 = Convert.ToDouble(txtn4.Text);
            //------------------------------------calculamos los demas valores
            objAlumno.NotaFinal = (objAlumno.Nota1 + objAlumno.Nota2 + objAlumno.Nota3 + objAlumno.Nota4) / 4;
            if (objAlumno.NotaFinal >= 3.5)
            {
                objAlumno.NotaConcepto = "Aprobado";
            }
            else
            {
                objAlumno.NotaConcepto = "Reprobado";
            }
            //---------------------------------------envio de alumno nuevo a la listaarray
            //agrego el objeto alumno al arreglo
            ListaAlumnos.Add(objAlumno);

            //alimento el datagrid o visualizo en el dg el arreglo            
            dgvdatos.DataSource = null;
            dgvdatos.DataSource = ListaAlumnos;            
            verArreglo();
        }

        private void InsertarDatosBorrados()
        {            
            clsestudiante objAlumno = new clsestudiante(); //Instancio la clase alumno y creo el objeto objAlumno // crea objeto objAlumno            
            //--------------------------------VALIDAR CAMPOS VACIOS

            //Desde los elementos del formulario creo el alumno nuevo
            objAlumno.Codigo = Convert.ToInt32(txtcodigo.Text);
            objAlumno.Nombre = txtnombre.Text;
            objAlumno.Correo = txtcorreo.Text;
            objAlumno.Nota1 = Convert.ToDouble(txtn1.Text);
            objAlumno.Nota2 = Convert.ToDouble(txtn2.Text);
            objAlumno.Nota3 = Convert.ToDouble(txtn3.Text);
            objAlumno.Nota4 = Convert.ToDouble(txtn4.Text);
            //------------------------------------calculamos los demas valores
            objAlumno.NotaFinal = (objAlumno.Nota1 + objAlumno.Nota2 + objAlumno.Nota3 + objAlumno.Nota4) / 4;
            if (objAlumno.NotaFinal >= 3.5)
            {
                objAlumno.NotaConcepto = "Aprobado";
            }
            else
            {
                objAlumno.NotaConcepto = "Reprobado";
            }            
            //agrego el objeto alumno al arreglo            
            AlumnosBorrados.Add(objAlumno);

            //alimento el datagrid o visualizo en el dg el arreglo
            FrmPapelera Recuperar = new FrmPapelera();
            Recuperar.dgborrados.DataSource = null;
            Recuperar.dgborrados.DataSource = AlumnosBorrados;
            dgborrados1.DataSource = null;
            dgborrados1.DataSource = AlumnosBorrados;
            //Recuperar.Show();
            verArreglo();
        }
        private void tsbeliminarusuario_Click(object sender, EventArgs e) //Boton Borrar
        {                        
            //Borrar datos Del Estudiante

            DialogResult ConfirmarBorrar = MessageBox.Show("Esta Seguro De Borrar", "Confirmar Borrada", MessageBoxButtons.OKCancel,MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (ConfirmarBorrar == DialogResult.OK)
            {
                clsestudiante MyAlumno = ObtenerDatos(Convert.ToInt32(txtcodigo.Text));
                ListaAlumnos.Remove(MyAlumno);
                dgvdatos.DataSource = null;
                dgvdatos.DataSource = ListaAlumnos;
                InsertarDatosBorrados();
                FrmPapelera borrados = new FrmPapelera();

                //crear nuestro archivo xml de los alumnos Borrados
                XmlSerializer Codificador = new XmlSerializer(typeof(List<clsestudiante>));
                TextWriter EscribirXml = new StreamWriter("C:/NET/AlumnosBorrados.xml");//Debug si no le pongo ruta
                Codificador.Serialize(EscribirXml, AlumnosBorrados);
                EscribirXml.Close();

                //Activar Botones

                tsbeditarusuario.Enabled = false;
                tsbeliminarusuario.Enabled = false;
                txtcodigo.Enabled = true;
                LimpiarCajas();
            }            
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {            
            FrmPapelera borrados = new FrmPapelera();
            FrmMenu menu = new FrmMenu();           
            borrados.Show();
            this.Hide();            
        }
    }
}
