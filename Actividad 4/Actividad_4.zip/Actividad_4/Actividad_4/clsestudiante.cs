﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_4
{
    public class clsestudiante
    {
        public int Codigo { get; set; }


        public string Nombre { get; set; } //propiedades

        public string Correo { get; set; }

        public double Nota1 { get; set; }

        public double Nota2 { get; set; }

        public double Nota3 { get; set; }

        public double Nota4 { get; set; }

        public double NotaFinal { get; set; }

        public string NotaConcepto { get; set; }
    }
}
